import React from 'react'
import Informations from './components/Informations'

const Information = () => {
  return (
    <Informations />
  )
}

export default Information