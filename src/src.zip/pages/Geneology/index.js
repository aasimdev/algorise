import React from 'react'
import GeneMap from './components/GeneMap'
import TotalRanking from './components/TotalRanking'

const index = () => {
  return (
    <>
      <GeneMap />
      <TotalRanking />
    </>
  )
}

export default index